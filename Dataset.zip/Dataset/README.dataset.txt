# nike > 2022-12-16 1:52pm
https://universe.roboflow.com/semantic-segmentation/nike-ookdr

Provided by a Roboflow user
License: CC BY 4.0

